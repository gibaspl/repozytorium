import { differenceInDays, differenceInWeeks } from "date-fns";

const birthDay = document.getElementById("birthday");

birthDay.addEventListener("change", (e) => {
  const date = e.target.value;
  const today = new Date();
  const getDate = new Date(date);

  if (
    getDate.getDate() == today.getDate() &&
    getDate.getMonth() == today.getMonth()
  ) {
    alert("Masz dzisiaj urodziny! Wszystkiego najlepszego!");
  }

  alert(
    "Od twoich urodzin minęło: " +
      differenceInDays(today, getDate) +
      " dni"
  );
  const birthdayThisYear = new Date(
    today.getFullYear(),
    getDate.getMonth(),
    getDate.getDate()
  );

  if (
    birthdayThisYear > today &&
    !(birthdayThisYear.getDate() === today.getDate() &&
      birthdayThisYear.getMonth() === today.getMonth())
  ) {
    const weeksToBirthday = differenceInWeeks(birthdayThisYear, today);

    if (weeksToBirthday === 0) {
      alert("Masz urodziny w tym tygodniu!");
    } else {
      alert("Do twoich urodzin zostało: " + weeksToBirthday + " tygodni");
    }
  }
});
